<footer>
	<p>
	<img src="https://licensebuttons.net/l/by-sa/3.0/88x31.png" height="31px" /><br/>
	<time datetime="2020-10-26">2020</time>.</p>
	</p>
	<address>
		<p class="izq"> Written by
			<a href="al375903@uji.es" rev="author">Enrique Gimeno </a> &
			<a href="al375825@uji.es" rev="author"> Edgar Heredia</a>.</p>
		<p class="der"> Visit us at: 12006 UJI </p>
	</address>
</footer>
</body>

</html>