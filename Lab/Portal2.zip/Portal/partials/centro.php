<!--<h1> Mi LOGO de tienda AQUÍ</h1>-->
<img src="./img/logo.png" /><br/>