<!DOCTYPE html>
<!--**
 * * Descripción: Cabecera portal Programa Aprender PHP
 * *
 * * Descripción extensa: Pagina web dividida en 4 ficheros.
 * *
 * * @author  Enrique Gimeno <al375903@uji.es>
 * * @author  Edgar Heredia <al375825@uji.es>
 * * @version 1
 * * @link http://localhost:3000/Lab/Portal/portal.php
 * * -->
<html>

<head>
	<meta charset="UTF-8">
	<title>Bienvenido a la web de MY LACKS</title>
	<META name="Author" content="AlumnoXXX">
	<link rel="stylesheet" href="./css/estilo.css" type="text/css">
	

</head>


<body>
	<header>
		<img src="./img/Dragon_Ball_anime_logo.png" id="logo" alt="logo" />
		<p id="eslogan">MyLacksWeb</p>
	</header>